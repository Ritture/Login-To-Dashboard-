package com.example.simplelogin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DashBoard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dash_board)
    }
}